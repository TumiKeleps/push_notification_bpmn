package za.co.telkom.crm.push_notifications.Enums;

public enum ProfileTypeEnum {
    ONNET,
    POSTLOGIN,
    ALL
}
