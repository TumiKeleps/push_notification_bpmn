package za.co.telkom.crm.push_notifications.mapper;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import za.co.telkom.crm.push_notifications.model.PushNotification;

@Component
public class PushNotificationUpdate {
     @Autowired
    private final ModelMapper modelMapper;

    public PushNotificationUpdate(ModelMapper modelMapper) {
        this.modelMapper = modelMapper;
    }

    public PushNotification updateCustomer(PushNotification in, PushNotification out) {
        modelMapper.map(in, out);
        return out;
    }
}
