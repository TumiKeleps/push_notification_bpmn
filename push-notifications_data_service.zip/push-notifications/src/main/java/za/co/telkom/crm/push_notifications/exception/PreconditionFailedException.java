package za.co.telkom.crm.push_notifications.exception;

public class PreconditionFailedException extends RuntimeException {

    private static final long serialVersionUID = 1L;

	public PreconditionFailedException(String message) {
        super(message);
    }
}
