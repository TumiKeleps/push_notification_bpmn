package za.co.telkom.crm.push_notifications.model;
import java.time.ZonedDateTime;


import jakarta.persistence.Column;
import jakarta.persistence.Entity;
import jakarta.persistence.EnumType;
import jakarta.persistence.Enumerated;
import jakarta.persistence.GeneratedValue;
import jakarta.persistence.GenerationType;
import jakarta.persistence.Id;
import jakarta.persistence.PrePersist;
import jakarta.persistence.Table;
import lombok.Data;
import za.co.telkom.crm.push_notifications.Enums.ApproveEnum;
import za.co.telkom.crm.push_notifications.Enums.CampaignTypeEnum;
import za.co.telkom.crm.push_notifications.Enums.CustomerEnum;
import za.co.telkom.crm.push_notifications.Enums.ProfileTypeEnum;

@Entity
@Table(name = "push_notification")
@Data
public class PushNotification 
{
    
    @Id
    @GeneratedValue(strategy = GenerationType.SEQUENCE)
    private Long id;
    @Column(name = "username")
    private String Username;

    @Enumerated(EnumType.STRING)
    @Column(nullable = true, name = "customertype")
    private CustomerEnum customerEnum;


    @Enumerated(EnumType.STRING)
    @Column(nullable = true, name="profiletype")
    private ProfileTypeEnum profileEnum;

    
    @Column(nullable = true,name = "launchtime")

    private ZonedDateTime LaunchTime;

    @Column(nullable = true, name = "startdate")
    private ZonedDateTime StartDate;

    @Column(nullable = true , name = "enddate")
    private ZonedDateTime EndDate;

    @Column(nullable = true , name = "header")
    private String Header;

    @Column(nullable = true , name = "creationdate")
    private ZonedDateTime CreationDate;

    @Column(nullable = true , name = "body")
    private String Body;

    @Column(nullable = true , name = "campaigntype")
    @Enumerated(EnumType.STRING)
    private CampaignTypeEnum CampaignType;

    @Column(nullable = true, name  ="approve")
    @Enumerated(EnumType.STRING)
    private ApproveEnum approveEnum;

    @PrePersist
    protected void onCreate()
    {
        if (this.CreationDate == null) 
        {
            this.CreationDate = ZonedDateTime.now();
        }
    }
    
}
