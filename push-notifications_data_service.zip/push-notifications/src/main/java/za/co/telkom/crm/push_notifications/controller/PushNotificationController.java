package za.co.telkom.crm.push_notifications.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;
import java.util.Map;

import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import lombok.extern.slf4j.Slf4j;
import za.co.telkom.crm.push_notifications.DTO.DTOPushNotification;
import za.co.telkom.crm.push_notifications.Enums.CustomerEnum;
import za.co.telkom.crm.push_notifications.Enums.ProfileTypeEnum;
import za.co.telkom.crm.push_notifications.exception.*;
import za.co.telkom.crm.push_notifications.mapper.PushNotificationMapper;
import za.co.telkom.crm.push_notifications.model.PushNotification;
import za.co.telkom.crm.push_notifications.service.PushNotificationService;


@RestController
@RequestMapping("/api/v1/push-notification")
@Slf4j
public class PushNotificationController {

	@Autowired
	private PushNotificationService service;


	@Autowired 
	private PushNotificationMapper mapper;
	// Create
	@PostMapping
	public @ResponseBody ResponseEntity<Object> create(@RequestBody final PushNotification resource) {
		log.debug("<==============  CREATING PUSHNOTIFICATION =============> ");
		PushNotification savedModel  = service.create(resource);
		DTOPushNotification dto = mapper.toDTO(savedModel);
		return new ResponseEntity<>(dto, HttpStatus.OK);
	}
	@PatchMapping("/{id}")
	public ResponseEntity<PushNotification>  patchPushNotification(@PathVariable(name = "id", required = true) String id, @RequestBody PushNotification pushNotification) {
		log.debug("<==============  PATCHING PUSHNOTIFICATION =============> ");
		return new ResponseEntity<>( service.patch(id, pushNotification) , HttpStatus.OK);
	}
	@GetMapping("/extended/customer/{type}")
	public ResponseEntity<List<PushNotification>> getCustomerTypeEnum(@PathVariable("type") String customerType) {
		log.debug("<==============  GET ALL CUSTOMERTYPE =============> ");
		CustomerEnum customerEnum;
		 customerEnum = CustomerEnum.valueOf(customerType.toUpperCase());
		 List<PushNotification> notifications = service.getPushNotificationsByCustomerEnum(customerEnum);
		 return new ResponseEntity<>( notifications, HttpStatus.OK);
		
	}
	@GetMapping("/extended/profile/{type}")
	public ResponseEntity<List<PushNotification>> getProfileTypeEnum(@PathVariable("type") String profileType)
	{
		log.debug("<==============  GET ALL CUSTOMERTYPE =============> ");
		ProfileTypeEnum profileEnum;
		 profileEnum = ProfileTypeEnum.valueOf(profileType.toUpperCase());
		 List<PushNotification> notifications = service.getPushNotificationsByProfileEnum(profileEnum);
		 return new ResponseEntity<>( notifications, HttpStatus.OK);
		
	}
	 	

	//Get All
	// @GetMapping
	// public ResponseEntity<Object> fetch(@RequestParam(name = "page", required = false) String page,
	// 		@RequestParam(name = "limit", required = false) String limit) {
	// 	return new ResponseEntity<>(service.fetch(page, limit), HttpStatus.OK);
	// }

	// Get By Id
	@GetMapping(value = "/{id}")
	public ResponseEntity<Object> fetch(@PathVariable(name = "id", required = true) Long resourceId) {
		return new ResponseEntity<>(service.fetch(resourceId), HttpStatus.OK);
	}

	// Patch
	// @PatchMapping(value = "/{id}")
	// public ResponseEntity<Object> patch(@PathVariable(name = "id", required = true) Long resourceId,
	// 		@RequestBody final PushNotification resourceFromRestAPI) {
	// 	return new ResponseEntity<>(service.patch(resourceId, resourceFromRestAPI), HttpStatus.OK);
	// }

	//Get push-notification by Nationality id
	// @GetMapping(value = "/extended/rsa-id-passport/{rsaIdPassport}")
	// public ResponseEntity<Object> getPushIdByNationalityId(
	// 		@PathVariable(name = "rsaIdPassport", required = true) String rsaIdPassport) {
	// 	return new ResponseEntity<>(service.getPushNotificationByRsaIdPassport(rsaIdPassport), HttpStatus.OK);
	// }

	// // Get By Id
	// @GetMapping(value = "/extended/push-id/{pushId}")
	// public ResponseEntity<Object> getPushNotificationByPushId(
	// 		@PathVariable(name = "pushId", required = true) String pushId) {
	// 	return new ResponseEntity<>(service.getPushNotificationByPushID(pushId), HttpStatus.OK);
	// }

	// // Get push-id by contract type
	// @PostMapping("/extended/contract-type")
	// public List<List<String>> getPushIdsByContractType(@RequestBody Map<String, List<String>> request) {
	// 	List<String> contractType = request.get("contractType");
	// 	if (contractType == null) {
	// 		return Collections.emptyList();
	// 	}
	// 	List<List<String>> result = new ArrayList<>();
	// 	for (String contractTypes : contractType) {
	// 		List<String> pushIds = service.getPushIdByContractType(contractType);
	// 		result.add(pushIds);
	// 	}

	// 	return result;
	// }

	// Global Exception Handler
	@ExceptionHandler(ResourceNotFoundException.class)
	public ResponseEntity<String> handleNotFound(ResourceNotFoundException ex) {
		return new ResponseEntity<>(ex.getMessage(), HttpStatus.NOT_FOUND);
	}
	
    // Global Exception Handler
    @ExceptionHandler(PreconditionFailedException.class)
    public ResponseEntity<String> handlePreconditionFailed(PreconditionFailedException ex) {
        return new ResponseEntity<>(ex.getMessage(), HttpStatus.PRECONDITION_FAILED);
    }

}
