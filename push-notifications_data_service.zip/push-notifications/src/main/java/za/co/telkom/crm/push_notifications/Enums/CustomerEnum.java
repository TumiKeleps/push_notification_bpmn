package za.co.telkom.crm.push_notifications.Enums;

public enum CustomerEnum {
    PREPAID,
    PASTPAID,
    HYBRID
}
// 0720397508