package za.co.telkom.crm.push_notifications.Enums;

public enum ApproveEnum {
    APPROVED,
    NOT_APPROVED,
    EXPIRED
}
