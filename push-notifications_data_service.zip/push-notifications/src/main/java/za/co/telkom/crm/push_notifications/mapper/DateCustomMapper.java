package za.co.telkom.crm.push_notifications.mapper;

import java.util.Date;

import org.threeten.bp.DateTimeUtils;
import org.threeten.bp.OffsetDateTime;

public class DateCustomMapper {

    // Returns a string representation of the address
    public org.threeten.bp.OffsetDateTime dateAsDate(org.threeten.bp.OffsetDateTime source){

        return source;
    }
    
    public Date offSetDateAsUtilDate(org.threeten.bp.OffsetDateTime source){
    		if(source == null)
    			return null;
        return DateTimeUtils.toDate(source.toInstant());
    }
    
    
    public org.threeten.bp.OffsetDateTime offSetDateAsUtilDate(Date source){
    		if(source == null)
			return null;
        return  OffsetDateTime.ofInstant(
        		DateTimeUtils.toInstant(source), org.threeten.bp.ZoneId.systemDefault());
    }
    
}