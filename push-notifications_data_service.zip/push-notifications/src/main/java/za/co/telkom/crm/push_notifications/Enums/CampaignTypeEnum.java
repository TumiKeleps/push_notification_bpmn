package za.co.telkom.crm.push_notifications.Enums;

public enum CampaignTypeEnum 
{
        GENERAL,
        MARKETING_DEAL,
        EDUCATIONAL
}
