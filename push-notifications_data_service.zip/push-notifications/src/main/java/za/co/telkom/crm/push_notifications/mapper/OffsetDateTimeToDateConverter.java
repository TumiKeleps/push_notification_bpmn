package za.co.telkom.crm.push_notifications.mapper;

import java.time.OffsetDateTime;
import java.util.Date;

import org.springframework.core.convert.converter.Converter;
public class OffsetDateTimeToDateConverter implements Converter<OffsetDateTime, Date> {

    @Override
    public Date convert(OffsetDateTime source) {
      if (source == null) {
        return null;
      }
      return Date.from(source.toInstant());
    }
  }
  