package za.co.telkom.crm.push_notifications.mapper;
import java.time.OffsetDateTime;
import java.time.ZoneId;
import java.util.Date;

import org.springframework.core.convert.converter.Converter;
public class DateTimeConverter implements Converter<Date, OffsetDateTime> 
{

    @Override
    public OffsetDateTime convert(Date source) 
    {
      if (source == null) {
        return null;
      }
      return source.toInstant().atZone(ZoneId.systemDefault()).toOffsetDateTime();
    }
}
  