package za.co.telkom.crm.push_notifications.service;

import com.google.gson.Gson;
import lombok.extern.slf4j.Slf4j;

// import org.mapstruct.factory.Mappers;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;

import za.co.telkom.crm.push_notifications.DTO.DTOPushNotification;
import za.co.telkom.crm.push_notifications.Enums.CustomerEnum;
import za.co.telkom.crm.push_notifications.Enums.ProfileTypeEnum;
import za.co.telkom.crm.push_notifications.exception.*;
// import za.co.telkom.crm.mapper.MamCacheMapper;
import za.co.telkom.crm.push_notifications.mapper.PushNotificationMapper;
import za.co.telkom.crm.push_notifications.mapper.PushNotificationUpdate;
import za.co.telkom.crm.push_notifications.model.PushNotification;
import za.co.telkom.crm.push_notifications.repo.PushNotificationRepository;


import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;

@Slf4j
@Service
public class PushNotificationService {

	@Autowired
	private PushNotificationRepository repository;

	@Autowired
	private PushNotificationUpdate pushNotificationUpdate;
	// @Value("${environment_host}")
	// private String environmentHost;

	// @Value("${environment_host}")
	// private String listOfResourcesNotFound;


	// Create
	public PushNotification create(PushNotification resource) {
		try {
			
			return repository.save(resource);
		}
		catch (Exception e) 
		{
			System.out.println(e.toString());
			throw new PreconditionFailedException(String.format("Resource already exits with PushId : %s",resource.getId()));
		}
	}

	private Pageable getPageLimit(String page, String limit)
	{
		Pageable limitPageable= PageRequest.of(0,15, Sort.by("creationDate").descending());

		//If number of pages and limit are set
		if(Objects.nonNull(limit) && !limit.isEmpty() && Objects.nonNull(page) && !page.isEmpty())
		{
			limitPageable = PageRequest.of(Integer.parseInt(page),Integer.parseInt(limit),Sort.by("creationDate").descending());
		}
		//If number of pages not set and limit is set
		else if (Objects.nonNull(limit) && !limit.isEmpty())
		{
			limitPageable = PageRequest.of(0,Integer.parseInt(limit),Sort.by("creationDate").descending());
		}
		//If number of pages is set and limit is not set
		else if (Objects.nonNull(page) && !page.isEmpty())
		{
			limitPageable = PageRequest.of(Integer.parseInt(page),15,Sort.by("creationDate").descending());
		}
		return limitPageable;

	}

	// Get All
	// public List<za.co.telkom.crm.push_notifications.model.PushNotification> fetch(String page, String limit) {

	// 	String finalErrorMessage = getFinalErrorMessage(page,limit);
	// 	Pageable limitsPageable = getPageLimit(page, limit);

	// 	//Find All Resources Using Pagelimit
	// 	Page<PushNotification> pushNotifications = repository.findAll(limitsPageable);


	// 	if (Objects.isNull(pushNotifications) || pushNotifications.isEmpty())
	// 		throw new ResourceNotFoundException("Resources are not found(PushNotification)");

	// 	List<PushNotification> resources = new ArrayList<PushNotification>();

	// 	for(PushNotification pushNotification :pushNotifications.getContent()) {

	// 		resources.add(pushNotification);
	// 	}

	// 	return resources;
	// }


	// Get By Id
	public PushNotification fetch(Long resourceId) {
		PushNotification resource = repository.findById(resourceId).orElseThrow(() -> new ResourceNotFoundException(
				String.format("Resources are not found(PushNotification) for ID : %s", resourceId)));
		return resource;
	}

//	Patch
	public PushNotification patch(String resourceId, PushNotification resourceFromRestAPI) {
		//log.info("@@ Starting patch push id", new Gson().toJson(resourceFromRestAPI));
		// First Do The Patch Magic
		PushNotification resourceFromDB = repository.findById(Long.parseLong(resourceId))
				.orElseThrow(() -> new ResourceNotFoundException(
						String.format("Resources are not found(PushNotification) for ID : %s", resourceId)));
		
		log.info("@@ Push => {}", resourceFromDB.getId());

		
		PushNotification updated = pushNotificationUpdate.updateCustomer(resourceFromRestAPI, resourceFromDB);

		return repository.save(updated);
	}

	// Get by customer Enum
	public List<PushNotification> getPushNotificationsByCustomerEnum(CustomerEnum customerEnum) {
        return repository.findAllByCustomerEnum(customerEnum);
    }

	//Get by profile Enum
	public List<PushNotification> getPushNotificationsByProfileEnum(ProfileTypeEnum profileEnum) {
        return repository.findAllByProfileEnum(profileEnum);
    }

	public List<PushNotification> getPushNotificationsByDuration(Date startDate, Date endDate) {
        return repository.findAllByDuration(startDate, endDate);
    }


	// public PushNotification getPushNotificationByRsaIdPassport(String rsaIdPassport) {

	// 	PushNotification resource = repository.getPushIdByRsaIdPassport(rsaIdPassport)
	// 			.orElseThrow(() -> new ResourceNotFoundException(String
	// 					.format("Resources are not found(PushNotification) for rsaIdPassport : %s", rsaIdPassport)));
	// 	return resource;

	// }

	// public PushNotification getPushNotificationByPushID(String pushId) {

	// 	PushNotification resource = repository.getPushNotificationByPushId(pushId);

	// 	if (Objects.isNull(resource))
	// 		throw new ResourceNotFoundException("Resources are not found(Customer)");
	// 	return resource;

	// }

	// public List<String> getPushIdByContractType(List<String> contractType) {
	// 	return repository.getPushIdByContractType(contractType);
	// }


	// private String getFinalErrorMessage(String page, String limit)
	// {
	// 	//If number of pages and limit not set use the default
	// 	String finalErrorMessage = String.format(listOfResourcesNotFound, 0,15);

	// 	//If number of pages and limit are set
	// 	if(Objects.nonNull(limit) && !limit.isEmpty() && Objects.nonNull(page) && !page.isEmpty())
	// 	{
	// 		finalErrorMessage = String.format(listOfResourcesNotFound, Integer.parseInt(page),Integer.parseInt(limit));
	// 	}
	// 	//If number of pages not set and limit is set
	// 	else if(Objects.nonNull(limit) && !limit.isEmpty())
	// 	{
	// 		finalErrorMessage = String.format(listOfResourcesNotFound, 0,Integer.parseInt(limit));
	// 	}
	// 	//If number of pages is set and limit is not set
	// 	else if(Objects.nonNull(limit) && !limit.isEmpty())
	// 	{
	// 		finalErrorMessage = String.format(listOfResourcesNotFound, Integer.parseInt(page),15);
	// 	}
	// 	return finalErrorMessage;
	// }
}
