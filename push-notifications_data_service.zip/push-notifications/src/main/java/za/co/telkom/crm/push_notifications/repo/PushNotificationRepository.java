package za.co.telkom.crm.push_notifications.repo;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import za.co.telkom.crm.push_notifications.Enums.CustomerEnum;
import za.co.telkom.crm.push_notifications.Enums.ProfileTypeEnum;
import za.co.telkom.crm.push_notifications.model.*;
import java.util.Date;
import java.util.List;
import java.util.Optional;

@Repository
public interface PushNotificationRepository extends JpaRepository<PushNotification,Long> {

	//Optional<PushNotification> getPushIdByRsaIdPassport(String rsaIdPassport);
	
	//PushNotification getPushNotificationById(@Param("Id") String Id);
	List<PushNotification> findAllByCustomerEnum(CustomerEnum customerEnum);
	List<PushNotification> findAllByProfileEnum(ProfileTypeEnum profileEnum);

	@Query("SELECT p FROM PushNotification p WHERE p.StartDate >= :startDate AND p.EndDate <= :endDate")
    List<PushNotification> findAllByDuration(@Param("startDate") Date startDate, @Param("endDate") Date endDate);
	//List<PushNotification> getPushNotificationByProfileType(ProfileTypeEnum ProfileType);

	//List<String> getPushIdByContractType(List<String> contractType);
}
