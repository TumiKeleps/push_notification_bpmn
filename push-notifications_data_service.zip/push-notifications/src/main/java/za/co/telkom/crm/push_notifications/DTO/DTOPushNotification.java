package za.co.telkom.crm.push_notifications.DTO;

import java.time.ZonedDateTime;

import lombok.Data;
import za.co.telkom.crm.push_notifications.Enums.ApproveEnum;
import za.co.telkom.crm.push_notifications.Enums.CampaignTypeEnum;
import za.co.telkom.crm.push_notifications.Enums.CustomerEnum;
import za.co.telkom.crm.push_notifications.Enums.ProfileTypeEnum;

@Data
public class DTOPushNotification 
{
    
    private String id;
    private String username;
    private CustomerEnum customerEnum;
    private ProfileTypeEnum profileEnum;
    private ZonedDateTime launchTime;
    private ZonedDateTime startDate;
    private ZonedDateTime endDate;
    private String header;
    private ZonedDateTime creationDate;
    private String body;
    private CampaignTypeEnum campaignType;
    private ApproveEnum approveEnum;
}
