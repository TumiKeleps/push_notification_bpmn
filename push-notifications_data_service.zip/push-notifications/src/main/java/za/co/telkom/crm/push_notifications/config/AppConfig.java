package za.co.telkom.crm.push_notifications.config;

import org.modelmapper.ModelMapper;
import org.modelmapper.TypeMap;
import org.modelmapper.convention.MatchingStrategies;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import za.co.telkom.crm.push_notifications.model.PushNotification;
import za.co.telkom.crm.push_notifications.DTO.DTOPushNotification;
import za.co.telkom.crm.push_notifications.Enums.CustomerEnum;
@Configuration
public class AppConfig
{
    // @Bean
    // public CustomerEnum customerEnum()
    // {
    
    // }
    @Bean
    public ModelMapper modelMapper() 
    {
         ModelMapper modelMapper = new ModelMapper();

        // Set the matching strategy to STRICT to ensure fields match exactly
        modelMapper.getConfiguration().setMatchingStrategy(MatchingStrategies.STRICT);

        // Configure ModelMapper to skip the ID field for PushNotification class
        TypeMap<DTOPushNotification, PushNotification> typeMap = modelMapper.createTypeMap(DTOPushNotification.class, PushNotification.class);
        typeMap.addMappings(mapper -> mapper.skip(PushNotification::setId));
        
        
        // Skip null values for all fields
        modelMapper.getConfiguration().setPropertyCondition(context -> context.getSource() != null);

        return modelMapper;
    }
}
